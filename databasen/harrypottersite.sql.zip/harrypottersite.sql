-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Dec 08, 2019 at 12:53 PM
-- Server version: 5.7.26
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `harrypottersite`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id_comment` int(11) NOT NULL,
  `title` varchar(40) NOT NULL,
  `username` varchar(255) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `text` varchar(250) NOT NULL,
  `id_post` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id_comment`, `title`, `username`, `time`, `text`, `id_post`) VALUES
(6, 'Thank you', 'Kim', '2019-12-07 22:05:08', 'I can not wait to get started!', 10),
(7, 'Awsome!', 'Bruger', '2019-12-07 22:25:39', '', 10),
(8, 'Username: Bruger123', 'Bruger', '2019-12-07 22:26:27', 'God idea.', 11);

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

CREATE TABLE `games` (
  `game_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `points` varchar(255) NOT NULL,
  `lives` varchar(255) NOT NULL,
  `score` int(255) NOT NULL,
  `dobby` varchar(255) NOT NULL,
  `timeleft` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `games`
--

INSERT INTO `games` (`game_id`, `username`, `time`, `points`, `lives`, `score`, `dobby`, `timeleft`) VALUES
(1, 'TEST', '2019-11-25 10:26:45', '2', '2', 2, '', ''),
(2, 'Bruger', '2019-11-29 16:55:41', '2', '2', 25, '3', '18'),
(3, 'TEST', '2019-11-25 10:57:45', '', '2', 2, '', ''),
(4, 'Bruger', '2019-11-29 16:55:48', '2', '3', 8, '3', ''),
(5, 'TEST', '2019-11-25 11:06:47', '0', '2', 2, '', ''),
(6, 'TEST', '2019-11-25 11:07:46', '1', '2', 2, '', ''),
(7, 'TEST', '2019-11-25 11:15:55', '0', '2', 4, '2', ''),
(8, 'TEST', '2019-11-25 14:18:42', '2', '2', 6, '2', ''),
(9, 'Bruger', '2019-11-29 16:55:56', '2', '2', 6, '2', ''),
(10, 'TEST', '2019-11-26 14:13:40', '2', '2', 6, '2', ''),
(11, 'Bruger', '2019-11-29 16:56:03', '1', '2', 5, '2', ''),
(12, 'KimTest', '2019-11-29 20:04:22', '13', '2', 31, '3', '13'),
(13, 'Kim', '2019-12-03 14:22:30', '16', '2', 32, '3', '11'),
(14, 'Kim', '2019-12-03 14:45:56', '4.5', '2', 30, '3', '20'),
(15, 'Kim', '2019-12-06 07:16:06', '7.5', '1', 31, '3', '19');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id_post` int(11) NOT NULL,
  `title` varchar(40) NOT NULL,
  `username` varchar(255) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `shorttext` varchar(200) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id_post`, `title`, `username`, `time`, `shorttext`, `text`) VALUES
(10, 'Welcome', 'Admin', '2019-12-07 22:23:49', 'Welcome to this game site. In this post can you read about the site. We are glad that you have joined us.', 'Hello wizard,\r\n<br><br>\r\nWe are glad that you have joined us. <br>\r\nWe hope that you will have fun and enjoy your time here with us. \r\n<br><br>\r\nFeel free to write to us on <a href=”mailto:kim@kragesand.dk”>kim@kragesand.dk</a> if you need any help, experience errors or have an idea to the game site. \r\n<br><br>\r\nThe playing rules to a game can be read on the game page. <br>\r\nCheating of any kind will follow to immediate expulsion.\r\n<br><br>\r\nOn the blog page can you read about new updates and changes. You can also make a post yourself if you have some wizard information you want to share with other wizards. <br>\r\nWe will post when there is new updates or changes. The post will contain all the information you will need to know about the update or change. If you have any questions, please write an email to <a href=”mailto:kim@kragesand.dk”>kim@kragesand.dk</a>.<br>\r\nAny post or comment with any kind of inappropriate will be removed without warning. <br>\r\nUsers who post hateful posts or comments will be banned without warning. <br>\r\n<br><br>\r\nEnjoy and have fyn. \r\n<br><br>\r\n<a href=”policy.php”>Read about personal data process and cookies</a>\r\n'),
(11, 'Wirazds Unite (App)', 'Kim', '2019-12-07 22:24:56', 'I do not think I am the only one on this page who is playing Harry Potter Wirazds Unite.', 'Let be friends in the game Wirazds Unite.\r\n<br>\r\nMy username is TestBruger. \r\n<br>\r\nIf you want then please share you username in the comment, then we all can be friends. ');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `firstname`, `lastname`, `adresse`, `phonenumber`, `username`, `email`, `password`) VALUES
(1, 'Admin', 'Stration', 'Adminstration', '45010101', 'Admin', 'admin@admin.dk', 'ceb85012811d4ebc264688e3d6d60f8a37cf5f9f7d7f2363150053dbdb8f0bfaa4f90d01eac9ec45cd70127545091905a6cd832ba8d22d4aa058cc3bfd5311ea'),
(2, 'Kim', 'Bohn', 'ghj', '678', 'Kimx4131', 'kim@kim.dk', '070eff61e0554c4406b711f8c628b3ac636ee35a5d621ad49f08c9be0bc15e2e4f2e28baa02ff3c7fc8714f0bd28a1221674979e8da1e16d7042bd65822ab1c6'),
(3, 'Test', 'Tester', 'test', '12345678', 'TEST', 'test@test.dk', 'b8c3b0efa0aa3d706cb6255d536933f44a8a6cb680618050a78c3a5772e0533a00c186a4d2f3acd31c6afca4576b3504df3814423c793bc89b193887b56626f3'),
(4, 'Bruger', 'Bruger', 'fghj', '456723321', 'Bruger', 'dk@dk.dk', '701a1cc82484a7515ed5dd54a621272895aeb553210af265c496d582a8f98de1c21191f3a5a49c664997af5c7f2561f2e5f210933818c96d6e7543db7b213be5'),
(5, 'Kim', 'Bohn', 'fghjklæ', '4567890', 'Kim', 'kim@bohn.dk', 'afb6db712189f3d900c7e6e76865e7f3083b2bff4c17c8365569a44ccdd5e5cdb80cf6f41eda01c3fa2185f2a47323177124ba98056058bdb2dbcf18527f59e6'),
(6, 'Kim', 'Bohn', 'TEST', '92345678', 'KimTest', 'kim@test.dk', 'afb6db712189f3d900c7e6e76865e7f3083b2bff4c17c8365569a44ccdd5e5cdb80cf6f41eda01c3fa2185f2a47323177124ba98056058bdb2dbcf18527f59e6');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id_comment`);

--
-- Indexes for table `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`game_id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id_post`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `games`
--
ALTER TABLE `games`
  MODIFY `game_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
